print ("Introduce un número")
let numero1 = Int (readLine()!)!

if numero1 % 2 == 0 {
  print ("El número es par")   
  } else {
  print ("El número es impar")
  }